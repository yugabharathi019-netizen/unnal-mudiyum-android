# Unnal Mudiyum (உன்னால் முடியும்)

A gym app for lean gaining, with a distraction shield. Android, Kotlin, Jetpack Compose.

## What it does

- **Shield**
  - Adult site block: a local VPN that only handles website name lookups. Blocked names fail to load. Everything else goes to Cloudflare's family DNS (1.1.1.3), which also blocks adult sites. Turning it off needs a 24-hour wait and a second confirmation.
  - Reels controller: Block, Limit (15 min a day) or Earn (mark your workout done first, then 15 min).
  - YouTube Shorts block, and a sleep lock that closes Instagram from 11 PM to 6 AM.
  - A lock screen with 2 daily passes. Each pass makes you wait 30 seconds, then gives 10 minutes.
- **Food**: calories, protein, carbs and fat, with South Indian quick-add foods (idli, dosa, pongal, kuzhambu, sundal and more). Values are approximate for one serving. Use "Add something else" for exact numbers.
- **Body**: weight log with a trend chart, height, BMI, weekly pace, goal weight.
- **Today**: everything on one screen.

All data stays on your phone.

## Build it

1. Install Android Studio (Koala or newer).
2. Open this folder (`unnal-mudiyum-android`). Let Gradle sync. It creates the Gradle wrapper for you.
3. Plug in a phone with USB debugging on, or start an emulator, and press Run.

This project was written without being compiled, so expect to fix a few small errors on the first build.

## Turn blocking on (on the phone)

1. Open the Shield tab.
2. **Adult sites**: tap "Turn on adult site block" and accept the VPN prompt.
3. **Reels guard**: tap "Open Accessibility settings", find Unnal Mudiyum and switch it on.
   - On Android 13 and newer, if the switch is greyed out: Settings > Apps > Unnal Mudiyum > three dots > "Allow restricted settings". Then try again.

## Known limits

- The Reels and Shorts detection uses the apps' own screen ids (in `ReelsGuardService.kt`). Instagram and YouTube can change them in an update. If blocking stops working, those ids are the first thing to check.
- Reels time is counted from screen events, capped at 3 seconds each, so it is approximate.
- Anyone with a different Private DNS or another VPN running can bypass the adult block. Android allows only one VPN at a time.
- The app does not restart the VPN after a phone reboot until you open it once.
- No app icon yet (Android uses a default one).

## Next

Workout logger, Tamil food search, meal photo scan, boot-time restart of the shield.


## Build an APK with GitHub (phone-friendly)

This repository includes `.github/workflows/android-apk.yml`. After you upload the project to a GitHub repository on the `main` branch:

1. Open the repository's **Actions** tab.
2. Select **Build Android APK**.
3. Tap **Run workflow** if it has not started automatically, choose `main`, then run it.
4. Open the completed workflow run and find **Artifacts**.
5. Download `unnal-mudiyum-debug-apk`, extract it, and install `app-debug.apk` on your Android phone. You may need to allow installation from your browser or Files app.

The workflow uses JDK 17 and Gradle 8.7. This produces a debug APK for testing, not a Play Store-signed release. The original project notes that it has not yet been compiled, so the first GitHub build may reveal source or dependency errors that need fixing.
