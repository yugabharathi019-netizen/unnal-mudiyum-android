package com.unnalmudiyum.app.shield

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unnalmudiyum.app.MainActivity
import com.unnalmudiyum.app.data.Prefs
import com.unnalmudiyum.app.ui.GoldButton
import com.unnalmudiyum.app.ui.U
import com.unnalmudiyum.app.ui.UnnalTheme
import kotlinx.coroutines.delay

class LockActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        val reason = intent.getStringExtra("reason") ?: "Reels can wait."
        val pkg = intent.getStringExtra("pkg")

        setContent {
            UnnalTheme {
                LockScreen(
                    reason = reason,
                    onOpenApp = {
                        startActivity(Intent(this, MainActivity::class.java))
                        finish()
                    },
                    onUnlocked = {
                        Prefs.usePass()
                        if (pkg != null) {
                            packageManager.getLaunchIntentForPackage(pkg)?.let { i -> startActivity(i) }
                        }
                        finish()
                    }
                )
            }
        }
    }
}

@Composable
private fun LockScreen(reason: String, onOpenApp: () -> Unit, onUnlocked: () -> Unit) {
    val passes = remember { Prefs.passesLeft() }
    var waiting by remember { mutableStateOf(false) }
    var seconds by remember { mutableIntStateOf(30) }

    LaunchedEffect(waiting) {
        if (waiting) {
            while (seconds > 0) {
                delay(1000)
                seconds--
            }
            onUnlocked()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(U.Bg)
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
    ) {
        Text("உன்னால் முடியும்", color = U.Gold, fontSize = 44.sp, fontWeight = FontWeight.Bold)
        Text("Reels can wait.", color = U.Text, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text(reason, color = U.Muted, fontSize = 16.sp)

        GoldButton("Open Unnal Mudiyum", onOpenApp)

        OutlinedButton(
            onClick = { waiting = true },
            enabled = passes > 0 && !waiting,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 52.dp)
        ) {
            Text(
                when {
                    passes <= 0 -> "No passes left today"
                    waiting -> "Unlocking in $seconds s"
                    else -> "Unlock 10 minutes (wait 30 s)"
                },
                color = U.Text
            )
        }
        Text(
            "$passes of 2 daily passes left. Each pass makes you wait 30 seconds first.",
            color = U.Muted, fontSize = 12.sp
        )
    }
}
