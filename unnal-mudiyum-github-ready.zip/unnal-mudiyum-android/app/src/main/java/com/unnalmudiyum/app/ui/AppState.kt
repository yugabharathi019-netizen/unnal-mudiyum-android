package com.unnalmudiyum.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** Buttons the Shield screen needs from the activity. */
class Actions(
    val enableAdult: () -> Unit,
    val disableAdult: () -> Unit,
    val openAccessibility: () -> Unit
)

/**
 * Screens read data inside [read] and change it inside [edit].
 * Every edit bumps [tick], which redraws whatever read it.
 */
class AppState {
    var tick by mutableIntStateOf(0)
        private set

    fun refresh() {
        tick++
    }

    fun <T> read(f: () -> T): T {
        @Suppress("UNUSED_VARIABLE")
        val t = tick
        return f()
    }

    fun edit(f: () -> Unit) {
        f()
        tick++
    }
}
