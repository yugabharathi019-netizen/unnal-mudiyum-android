package com.unnalmudiyum.app.shield

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import com.unnalmudiyum.app.data.Prefs

/**
 * Watches Instagram and YouTube. When the Reels or Shorts screen is open and
 * your rules say it should be closed, it sends you home and shows the lock screen.
 *
 * The view ids below come from the apps themselves. They can change when
 * Instagram or YouTube update, so if blocking stops working, check them first.
 */
class ReelsGuardService : AccessibilityService() {

    companion object {
        const val IG = "com.instagram.android"
        const val YT = "com.google.android.youtube"
        const val LIMIT_MINUTES = 15

        private val IG_REELS_IDS = listOf(
            "$IG:id/clips_viewer_view_pager",
            "$IG:id/clips_viewer_container"
        )
        private val YT_SHORTS_IDS = listOf(
            "$YT:id/reel_recycler",
            "$YT:id/reel_player_page_container"
        )

        fun isEnabled(ctx: Context): Boolean {
            val enabled = Settings.Secure.getString(
                ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabled.contains(ctx.packageName)
        }
    }

    private var lastTick = 0L
    private var lastLock = 0L

    override fun onServiceConnected() {
        Prefs.init(this)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        if (pkg != IG && pkg != YT) return
        Prefs.init(this)

        val now = System.currentTimeMillis()
        if (Prefs.passActive(now)) return

        if (pkg == IG && Prefs.sleepLock && Prefs.inSleepWindow()) {
            lock(pkg, "It's sleep time. Rest is where muscle grows.")
            return
        }

        val root = rootInActiveWindow ?: return
        val ids = if (pkg == IG) IG_REELS_IDS else YT_SHORTS_IDS
        val inside = ids.any { root.findAccessibilityNodeInfosByViewId(it).isNotEmpty() }
        if (!inside) {
            lastTick = 0L
            return
        }

        if (pkg == YT) {
            if (Prefs.shortsBlock) lock(pkg, "Shorts are closed. Go lift.")
            return
        }

        when (Prefs.reelsMode) {
            "block" -> lock(pkg, "Reels are closed.")
            "earn" -> if (!Prefs.workoutDone) {
                lock(pkg, "Do your workout first. Then Reels open.")
            } else {
                count(now, pkg)
            }
            else -> count(now, pkg)
        }
    }

    /** Adds the time since the last event, up to 3 seconds, to today's Reels time. */
    private fun count(now: Long, pkg: String) {
        val dt = if (lastTick == 0L) 0L else minOf(now - lastTick, 3000L)
        lastTick = now
        Prefs.addReelsMillis(dt)
        if (Prefs.reelsMillis() >= LIMIT_MINUTES * 60_000L) {
            lock(pkg, "You used today's $LIMIT_MINUTES minutes of Reels.")
        }
    }

    private fun lock(pkg: String, reason: String) {
        val now = System.currentTimeMillis()
        if (now - lastLock < 3000L) return
        lastLock = now
        Prefs.incBlocked()
        performGlobalAction(GLOBAL_ACTION_HOME)
        val i = Intent(this, LockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("reason", reason)
            .putExtra("pkg", pkg)
        startActivity(i)
    }

    override fun onInterrupt() {}
}
