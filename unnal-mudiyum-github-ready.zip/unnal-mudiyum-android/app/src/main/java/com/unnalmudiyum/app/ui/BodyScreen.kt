package com.unnalmudiyum.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unnalmudiyum.app.data.Prefs

private fun parseNum(s: String): Float? = s.trim().replace(',', '.').toFloatOrNull()

@Composable
fun BodyScreen(state: AppState) {
    val weights = state.read { Prefs.weights() }
    val height = state.read { Prefs.heightCm }
    val goal = state.read { Prefs.goalKg }
    var showWeight by remember { mutableStateOf(false) }
    var showProfile by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Body", "Weight and height, week by week.")

        UCard {
            if (weights.isEmpty()) {
                Text("No weight logged yet", color = U.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("Log your weight once a week, same time of day, for a clear trend.", color = U.Muted, fontSize = 13.sp)
            } else {
                val now = weights.last().kg
                val start = weights.first().kg
                val frac = if (goal > start) ((now - start) / (goal - start)).coerceIn(0f, 1f) else 0f
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("%.1f".format(now), color = U.Text, fontSize = 52.sp, fontWeight = FontWeight.Bold)
                    Text("kg", color = U.Muted, fontSize = 16.sp, modifier = Modifier.padding(bottom = 10.dp))
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(U.Track)
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(frac)
                            .height(8.dp)
                            .background(U.Gold)
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Start %.1f kg".format(start), color = U.Muted, fontSize = 12.sp)
                    Text("Goal %.1f kg".format(goal), color = U.Muted, fontSize = 12.sp)
                }
            }
        }

        if (weights.size >= 2) {
            UCard {
                SectionLabel("Weight, last ${minOf(8, weights.size)} entries")
                Canvas(
                    Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                ) {
                    val pts = weights.takeLast(8)
                    val pad = 12f
                    val lo = pts.minOf { it.kg } - 0.3f
                    val hi = pts.maxOf { it.kg } + 0.3f
                    val span = (hi - lo).coerceAtLeast(0.5f)
                    val w = size.width - 2 * pad
                    val h = size.height - 2 * pad
                    fun x(i: Int) = pad + w * i / (pts.size - 1)
                    fun y(v: Float) = pad + h * (1f - (v - lo) / span)
                    val path = Path()
                    pts.forEachIndexed { i, p ->
                        if (i == 0) path.moveTo(x(i), y(p.kg)) else path.lineTo(x(i), y(p.kg))
                    }
                    drawPath(path, U.Gold, style = Stroke(6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    pts.forEachIndexed { i, p -> drawCircle(U.Gold, 8f, Offset(x(i), y(p.kg))) }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            UCard(Modifier.weight(1f)) {
                SectionLabel("Height")
                Text(
                    if (height > 0f) "%.0f cm".format(height) else "Not set",
                    color = U.Text, fontSize = 28.sp, fontWeight = FontWeight.Bold
                )
                Text("Measure every 3 months", color = U.Muted, fontSize = 12.sp)
            }
            UCard(Modifier.weight(1f)) {
                SectionLabel("BMI")
                val bmi = if (height > 0f && weights.isNotEmpty()) {
                    weights.last().kg / ((height / 100f) * (height / 100f))
                } else 0f
                Text(
                    if (bmi > 0f) "%.1f".format(bmi) else "–",
                    color = U.Text, fontSize = 28.sp, fontWeight = FontWeight.Bold
                )
                val goalBmi = if (height > 0f) goal / ((height / 100f) * (height / 100f)) else 0f
                Text(
                    if (goalBmi > 0f) "%.0f kg would be %.1f".format(goal, goalBmi) else "Set your height",
                    color = U.Muted, fontSize = 12.sp
                )
            }
        }

        if (weights.size >= 2) {
            val first = weights.first()
            val last = weights.last()
            val days = java.time.temporal.ChronoUnit.DAYS.between(
                java.time.LocalDate.parse(first.day), java.time.LocalDate.parse(last.day)
            ).coerceAtLeast(1)
            val perWeek = (last.kg - first.kg) / days * 7f
            UCard {
                Text("%+.2f kg a week".format(perWeek), color = U.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "A steady lean gain is 0.25 to 0.5 kg a week.",
                    color = U.Muted, fontSize = 13.sp
                )
            }
        }

        GoldButton("Log today's weight", { showWeight = true })
        TextButton({ showProfile = true }, Modifier.fillMaxWidth()) {
            Text("Set height and goal weight", color = U.Gold)
        }
    }

    if (showWeight) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showWeight = false },
            containerColor = U.Surface,
            title = { Text("Today's weight", color = U.Text) },
            text = {
                OutlinedTextField(
                    text, { text = it }, label = { Text("Weight (kg)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            },
            confirmButton = {
                TextButton({
                    val kg = parseNum(text)
                    if (kg != null && kg in 20f..300f) {
                        state.edit { Prefs.logWeight(kg) }
                        showWeight = false
                    }
                }) { Text("Save", color = U.Gold) }
            },
            dismissButton = { TextButton({ showWeight = false }) { Text("Cancel", color = U.Muted) } }
        )
    }

    if (showProfile) {
        var h by remember { mutableStateOf(if (height > 0f) "%.0f".format(height) else "") }
        var g by remember { mutableStateOf("%.0f".format(goal)) }
        AlertDialog(
            onDismissRequest = { showProfile = false },
            containerColor = U.Surface,
            title = { Text("Height and goal", color = U.Text) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        h, { h = it }, label = { Text("Height (cm)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                    OutlinedTextField(
                        g, { g = it }, label = { Text("Goal weight (kg)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                }
            },
            confirmButton = {
                TextButton({
                    val hv = parseNum(h)
                    val gv = parseNum(g)
                    state.edit {
                        if (hv != null && hv in 100f..250f) Prefs.heightCm = hv
                        if (gv != null && gv in 20f..300f) Prefs.goalKg = gv
                    }
                    showProfile = false
                }) { Text("Save", color = U.Gold) }
            },
            dismissButton = { TextButton({ showProfile = false }) { Text("Cancel", color = U.Muted) } }
        )
    }
}
