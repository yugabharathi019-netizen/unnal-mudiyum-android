package com.unnalmudiyum.app

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Restaurant
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Straighten
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.unnalmudiyum.app.data.Prefs
import com.unnalmudiyum.app.shield.DnsBlockerVpnService
import com.unnalmudiyum.app.ui.Actions
import com.unnalmudiyum.app.ui.AppState
import com.unnalmudiyum.app.ui.BodyScreen
import com.unnalmudiyum.app.ui.FoodScreen
import com.unnalmudiyum.app.ui.ShieldScreen
import com.unnalmudiyum.app.ui.TodayScreen
import com.unnalmudiyum.app.ui.U
import com.unnalmudiyum.app.ui.UnnalTheme

class MainActivity : ComponentActivity() {

    private val state = AppState()

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                startVpnService()
            } else {
                Prefs.adultBlock = false
            }
            state.refresh()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)

        // Bring the adult block back after a phone restart or app update.
        if (Prefs.adultBlock && !DnsBlockerVpnService.running && VpnService.prepare(this) == null) {
            startVpnService()
        }

        val actions = Actions(
            enableAdult = { enableAdult() },
            disableAdult = { disableAdult() },
            openAccessibility = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        )

        setContent {
            UnnalTheme {
                App(state, actions)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        state.refresh()
    }

    private fun enableAdult() {
        Prefs.adultBlock = true
        val ask = VpnService.prepare(this)
        if (ask != null) vpnPermission.launch(ask) else startVpnService()
        state.refresh()
    }

    private fun disableAdult() {
        Prefs.adultBlock = false
        Prefs.adultOffRequestedAt = 0L
        startService(Intent(this, DnsBlockerVpnService::class.java).setAction(DnsBlockerVpnService.ACTION_STOP))
        state.refresh()
    }

    private fun startVpnService() {
        startService(Intent(this, DnsBlockerVpnService::class.java).setAction(DnsBlockerVpnService.ACTION_START))
    }
}

private data class Tab(val label: String, val icon: ImageVector)

@Composable
private fun App(state: AppState, actions: Actions) {
    val tabs = remember {
        listOf(
            Tab("Today", Icons.Outlined.Home),
            Tab("Shield", Icons.Outlined.Shield),
            Tab("Food", Icons.Outlined.Restaurant),
            Tab("Body", Icons.Outlined.Straighten)
        )
    }
    var tab by remember { mutableIntStateOf(0) }

    Scaffold(
        containerColor = U.Bg,
        bottomBar = {
            NavigationBar(containerColor = U.Bg) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = U.Gold,
                            selectedTextColor = U.Gold,
                            indicatorColor = U.Raised,
                            unselectedIconColor = U.Muted,
                            unselectedTextColor = U.Muted
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> TodayScreen(state) { tab = it }
                1 -> ShieldScreen(state, actions)
                2 -> FoodScreen(state)
                else -> BodyScreen(state)
            }
        }
    }
}
