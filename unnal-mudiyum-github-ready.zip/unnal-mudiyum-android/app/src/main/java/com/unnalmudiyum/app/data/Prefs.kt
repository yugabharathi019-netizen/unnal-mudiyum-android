package com.unnalmudiyum.app.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime

data class Food(
    val day: String,
    val name: String,
    val kcal: Int,
    val protein: Int,
    val carbs: Int,
    val fat: Int
)

data class Weight(val day: String, val kg: Float)

/** All app data lives here. The accessibility service and VPN service read it too. */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.applicationContext.getSharedPreferences("unnal", Context.MODE_PRIVATE)
        }
    }

    fun today(): String = LocalDate.now().toString()

    // ---- Targets and profile ----
    var targetKcal: Int
        get() = sp.getInt("t_kcal", 2800)
        set(v) { sp.edit().putInt("t_kcal", v).apply() }

    var targetProtein: Int
        get() = sp.getInt("t_protein", 120)
        set(v) { sp.edit().putInt("t_protein", v).apply() }

    var goalKg: Float
        get() = sp.getFloat("goal_kg", 62f)
        set(v) { sp.edit().putFloat("goal_kg", v).apply() }

    /** 0 means not set yet. */
    var heightCm: Float
        get() = sp.getFloat("height_cm", 0f)
        set(v) { sp.edit().putFloat("height_cm", v).apply() }

    // ---- Food log ----
    private fun allFoods(): List<Food> {
        val arr = JSONArray(sp.getString("foods", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Food(
                o.getString("day"), o.getString("name"),
                o.getInt("kcal"), o.getInt("protein"), o.getInt("carbs"), o.getInt("fat")
            )
        }
    }

    private fun saveFoods(list: List<Food>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("day", it.day).put("name", it.name).put("kcal", it.kcal)
                    .put("protein", it.protein).put("carbs", it.carbs).put("fat", it.fat)
            )
        }
        sp.edit().putString("foods", arr.toString()).apply()
    }

    fun foodsToday(): List<Food> = allFoods().filter { it.day == today() }

    fun addFood(f: Food) = saveFoods(allFoods() + f)

    /** Removes the nth food logged today. */
    fun removeFoodToday(todayIndex: Int) {
        val all = allFoods().toMutableList()
        var n = -1
        val idx = all.indexOfFirst {
            if (it.day == today()) {
                n++
                n == todayIndex
            } else false
        }
        if (idx >= 0) {
            all.removeAt(idx)
            saveFoods(all)
        }
    }

    // ---- Weight log ----
    fun weights(): List<Weight> {
        val arr = JSONArray(sp.getString("weights", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Weight(o.getString("day"), o.getDouble("kg").toFloat())
        }.sortedBy { it.day }
    }

    fun logWeight(kg: Float) {
        val list = weights().filter { it.day != today() } + Weight(today(), kg)
        val arr = JSONArray()
        list.sortedBy { it.day }.forEach {
            arr.put(JSONObject().put("day", it.day).put("kg", it.kg.toDouble()))
        }
        sp.edit().putString("weights", arr.toString()).apply()
    }

    // ---- Shield settings ----
    var adultBlock: Boolean
        get() = sp.getBoolean("adult_block", false)
        set(v) { sp.edit().putBoolean("adult_block", v).apply() }

    /** Time the user asked to turn the adult block off. 0 means no request. */
    var adultOffRequestedAt: Long
        get() = sp.getLong("adult_off_at", 0L)
        set(v) { sp.edit().putLong("adult_off_at", v).apply() }

    /** "block", "limit" or "earn". */
    var reelsMode: String
        get() = sp.getString("reels_mode", "limit") ?: "limit"
        set(v) { sp.edit().putString("reels_mode", v).apply() }

    var shortsBlock: Boolean
        get() = sp.getBoolean("shorts_block", true)
        set(v) { sp.edit().putBoolean("shorts_block", v).apply() }

    var sleepLock: Boolean
        get() = sp.getBoolean("sleep_lock", true)
        set(v) { sp.edit().putBoolean("sleep_lock", v).apply() }

    fun inSleepWindow(): Boolean {
        val h = LocalTime.now().hour
        return h >= 23 || h < 6
    }

    // ---- Daily counters ----
    var workoutDone: Boolean
        get() = sp.getString("workout_day", "") == today()
        set(v) { sp.edit().putString("workout_day", if (v) today() else "").apply() }

    fun reelsMillis(): Long =
        if (sp.getString("rm_day", "") == today()) sp.getLong("rm", 0L) else 0L

    fun addReelsMillis(ms: Long) {
        val cur = reelsMillis()
        sp.edit().putString("rm_day", today()).putLong("rm", cur + ms).apply()
    }

    fun blockedToday(): Int =
        if (sp.getString("bk_day", "") == today()) sp.getInt("bk", 0) else 0

    fun incBlocked() {
        val cur = blockedToday()
        sp.edit().putString("bk_day", today()).putInt("bk", cur + 1).apply()
    }

    private fun passesUsed(): Int =
        if (sp.getString("ps_day", "") == today()) sp.getInt("ps", 0) else 0

    fun passesLeft(): Int = (2 - passesUsed()).coerceAtLeast(0)

    /** Spends one daily pass and opens a 10 minute window. */
    fun usePass(): Boolean {
        if (passesLeft() <= 0) return false
        sp.edit().putString("ps_day", today()).putInt("ps", passesUsed() + 1)
            .putLong("pass_until", System.currentTimeMillis() + 10 * 60_000L).apply()
        return true
    }

    fun passActive(now: Long): Boolean = now < sp.getLong("pass_until", 0L)
}
