package com.unnalmudiyum.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unnalmudiyum.app.data.Food
import com.unnalmudiyum.app.data.Prefs

/** Approximate values for one common serving. Use Custom for exact numbers. */
private data class Preset(val name: String, val kcal: Int, val p: Int, val c: Int, val f: Int)

private val presets = listOf(
    Preset("Idli (2)", 120, 4, 25, 1),
    Preset("Dosa (1)", 168, 4, 29, 4),
    Preset("Pongal (1 cup)", 240, 6, 35, 9),
    Preset("Boiled egg", 78, 6, 1, 5),
    Preset("Rice (1 cup)", 205, 4, 45, 0),
    Preset("Sambar (1 cup)", 110, 5, 17, 3),
    Preset("Chicken curry (1 cup)", 240, 24, 6, 13),
    Preset("Paneer (100 g)", 265, 18, 4, 20),
    Preset("Curd bowl", 120, 7, 9, 6),
    Preset("Sundal bowl", 210, 11, 32, 4),
    Preset("Peanut chikki", 150, 4, 15, 9),
    Preset("Banana", 105, 1, 27, 0),
    Preset("Filter coffee", 90, 3, 10, 4)
)

@Composable
fun FoodScreen(state: AppState) {
    val foods = state.read { Prefs.foodsToday() }
    val tk = state.read { Prefs.targetKcal }
    val tp = state.read { Prefs.targetProtein }
    val kcal = foods.sumOf { it.kcal }
    val protein = foods.sumOf { it.protein }
    val carbs = foods.sumOf { it.carbs }
    val fat = foods.sumOf { it.fat }
    var showCustom by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenHeader("Food", "Eat more, on purpose. Target %,d kcal and %d g protein.".format(tk, tp))

        UCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Ring(protein / tp.toFloat(), U.Gold, 104.dp, 10.dp) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$protein", color = U.Text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text("g protein", color = U.Muted, fontSize = 11.sp)
                    }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
                        Text("%,d".format(kcal), color = U.Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text("of %,d kcal".format(tk), color = U.Muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
                    }
                    LinearProgressIndicator(
                        progress = { (kcal / tk.toFloat()).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 8.dp),
                        color = U.Ivory,
                        trackColor = U.Track
                    )
                    Text(
                        "%,d kcal left · %d g protein left".format((tk - kcal).coerceAtLeast(0), (tp - protein).coerceAtLeast(0)),
                        color = U.Text, fontSize = 13.sp
                    )
                    Text("Carbs $carbs g · Fat $fat g", color = U.Muted, fontSize = 12.sp)
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionLabel("Quick add")
            presets.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    pair.forEach { p ->
                        PresetButton(p, Modifier.weight(1f)) {
                            state.edit {
                                Prefs.addFood(Food(Prefs.today(), p.name, p.kcal, p.p, p.c, p.f))
                            }
                        }
                    }
                    if (pair.size == 1) Box(Modifier.weight(1f))
                }
            }
            TextButton({ showCustom = true }) { Text("Add something else", color = U.Gold) }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionLabel("Today's food")
            if (foods.isEmpty()) {
                Text("Nothing logged yet. Tap a food above.", color = U.Muted, fontSize = 13.sp)
            }
            foods.forEachIndexed { i, f ->
                UCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(f.name, color = U.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("${f.kcal} kcal · ${f.protein} g protein", color = U.Muted, fontSize = 12.sp)
                        }
                        IconButton({ state.edit { Prefs.removeFoodToday(i) } }) {
                            Icon(Icons.Outlined.Delete, contentDescription = "Remove ${f.name}", tint = U.Muted)
                        }
                    }
                }
            }
        }
    }

    if (showCustom) {
        CustomFoodDialog(
            onDismiss = { showCustom = false },
            onAdd = { f ->
                state.edit { Prefs.addFood(f) }
                showCustom = false
            }
        )
    }
}

@Composable
private fun PresetButton(p: Preset, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier
            .heightIn(min = 56.dp)
            .clip(shape)
            .background(U.Surface)
            .border(1.dp, U.Line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(p.name, color = U.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Text("+${p.kcal} kcal · ${p.p} g protein", color = U.Muted, fontSize = 12.sp)
    }
}

@Composable
private fun CustomFoodDialog(onDismiss: () -> Unit, onAdd: (Food) -> Unit) {
    var name by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf("") }
    var protein by remember { mutableStateOf("") }
    var carbs by remember { mutableStateOf("") }
    var fat by remember { mutableStateOf("") }
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Number)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = U.Surface,
        title = { Text("Add food", color = U.Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(kcal, { kcal = it }, label = { Text("Calories (kcal)") }, singleLine = true, keyboardOptions = numeric)
                OutlinedTextField(protein, { protein = it }, label = { Text("Protein (g)") }, singleLine = true, keyboardOptions = numeric)
                OutlinedTextField(carbs, { carbs = it }, label = { Text("Carbs (g), optional") }, singleLine = true, keyboardOptions = numeric)
                OutlinedTextField(fat, { fat = it }, label = { Text("Fat (g), optional") }, singleLine = true, keyboardOptions = numeric)
            }
        },
        confirmButton = {
            TextButton({
                val k = kcal.toIntOrNull()
                if (name.isNotBlank() && k != null) {
                    onAdd(
                        Food(
                            Prefs.today(), name.trim(), k,
                            protein.toIntOrNull() ?: 0, carbs.toIntOrNull() ?: 0, fat.toIntOrNull() ?: 0
                        )
                    )
                }
            }) { Text("Add", color = U.Gold) }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = U.Muted) } }
    )
}
