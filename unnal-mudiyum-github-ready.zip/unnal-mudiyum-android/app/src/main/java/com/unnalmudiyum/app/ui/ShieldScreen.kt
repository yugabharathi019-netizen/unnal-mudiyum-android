package com.unnalmudiyum.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unnalmudiyum.app.data.Prefs
import com.unnalmudiyum.app.shield.DnsBlockerVpnService
import com.unnalmudiyum.app.shield.ReelsGuardService

private const val DAY_MS = 24L * 60 * 60 * 1000

@Composable
fun ShieldScreen(state: AppState, a: Actions) {
    val ctx = LocalContext.current
    val adultOn = state.read { Prefs.adultBlock }
    val vpnUp = state.read { DnsBlockerVpnService.running }
    val offAt = state.read { Prefs.adultOffRequestedAt }
    val mode = state.read { Prefs.reelsMode }
    val shorts = state.read { Prefs.shortsBlock }
    val sleep = state.read { Prefs.sleepLock }
    val blocked = state.read { Prefs.blockedToday() }
    val reelsMin = state.read { (Prefs.reelsMillis() / 60000L).toInt() }
    val guardOn = state.read { ReelsGuardService.isEnabled(ctx) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Shield", "Distractions off. Gym on.")

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            UCard(Modifier.weight(1f)) {
                Text("$blocked", color = U.Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("attempts blocked today", color = U.Muted, fontSize = 13.sp)
            }
            UCard(Modifier.weight(1f)) {
                Text("$reelsMin min", color = U.Text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Reels watched today", color = U.Muted, fontSize = 13.sp)
            }
        }

        // Reels guard permission
        if (!guardOn) {
            UCard {
                Text("Turn on the Reels guard", color = U.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Android needs you to switch on Unnal Mudiyum in Accessibility settings. " +
                        "It only checks which screen is open in Instagram and YouTube. It does not read your messages.",
                    color = U.Muted, fontSize = 13.sp
                )
                GoldButton("Open Accessibility settings", a.openAccessibility)
            }
        }

        // Adult sites
        UCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Adult websites", color = U.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (adultOn && vpnUp) "Blocked in every browser and app"
                        else if (adultOn) "Starting…"
                        else "Off",
                        color = U.Muted, fontSize = 13.sp
                    )
                }
                if (adultOn) {
                    Text("Locked", color = U.Leaf, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            if (!adultOn) {
                GoldButton("Turn on adult site block", a.enableAdult)
                Text(
                    "Uses a private on-device VPN that only handles website name lookups. Nothing else is routed or stored.",
                    color = U.Muted, fontSize = 12.sp
                )
            } else {
                val now = System.currentTimeMillis()
                when {
                    offAt == 0L -> {
                        Text("Turning this off needs a 24-hour wait and a second confirmation.", color = U.Muted, fontSize = 12.sp)
                        TextButton({ state.edit { Prefs.adultOffRequestedAt = now } }) {
                            Text("Ask to turn off", color = U.Muted)
                        }
                    }
                    now - offAt >= DAY_MS -> {
                        Text("The 24 hours are over. You can turn it off now.", color = U.Muted, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(a.disableAdult) { Text("Confirm turn off", color = U.Gold) }
                            TextButton({ state.edit { Prefs.adultOffRequestedAt = 0L } }) { Text("Keep it on", color = U.Muted) }
                        }
                    }
                    else -> {
                        val hrs = ((DAY_MS - (now - offAt)) / 3_600_000L) + 1
                        Text("You can turn it off in about $hrs hours.", color = U.Muted, fontSize = 12.sp)
                        TextButton({ state.edit { Prefs.adultOffRequestedAt = 0L } }) {
                            Text("Cancel and keep it on", color = U.Gold)
                        }
                    }
                }
            }
        }

        // Reels controller
        UCard {
            Text("Instagram Reels", color = U.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Segmented(
                listOf("block" to "Block", "limit" to "Limit", "earn" to "Earn"),
                mode
            ) { state.edit { Prefs.reelsMode = it } }
            Text(
                when (mode) {
                    "block" -> "Reels are closed all day. Messages, posts and stories still work."
                    "earn" -> "Reels stay closed until you mark today's workout done. Then you get 15 minutes."
                    else -> "You get 15 minutes of Reels a day, then they close until tomorrow."
                },
                color = U.Muted, fontSize = 13.sp
            )
        }

        // Switches
        UCard {
            SwitchRow("YouTube Shorts", "Short videos stay closed", shorts) { state.edit { Prefs.shortsBlock = it } }
            SwitchRow("Sleep lock", "11 PM to 6 AM, Instagram closed", sleep) { state.edit { Prefs.sleepLock = it } }
        }
    }
}

@Composable
private fun Segmented(options: List<Pair<String, String>>, selected: String, onPick: (String) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(U.Bg)
            .border(1.dp, U.Line, shape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEach { (id, label) ->
            val on = id == selected
            Box(
                Modifier
                    .weight(1f)
                    .heightIn(min = 44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (on) U.Gold else Color.Transparent)
                    .clickable { onPick(id) },
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (on) U.OnGold else U.Text, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = U.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = U.Muted, fontSize = 12.sp)
        }
        Switch(
            checked = on,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = U.OnGold,
                checkedTrackColor = U.Gold,
                uncheckedThumbColor = U.Text,
                uncheckedTrackColor = Color(0xFF3A3228),
                uncheckedBorderColor = Color(0xFF3A3228)
            )
        )
    }
}
