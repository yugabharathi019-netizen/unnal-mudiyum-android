package com.unnalmudiyum.app.shield

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

/**
 * A local VPN that only captures DNS lookups. Blocked names get an NXDOMAIN
 * answer. Everything else is forwarded to Cloudflare's family DNS (1.1.1.3).
 * No other traffic goes through this VPN and nothing leaves your phone except
 * the DNS lookups themselves.
 */
class DnsBlockerVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.unnalmudiyum.app.START_VPN"
        const val ACTION_STOP = "com.unnalmudiyum.app.STOP_VPN"
        private const val VPN_DNS = "10.111.0.2"
        private const val UPSTREAM = "1.1.1.3"

        @Volatile
        var running = false
    }

    private var tun: ParcelFileDescriptor? = null
    private var loop: Thread? = null
    private val pool = Executors.newFixedThreadPool(6)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            stopSelf()
            return START_NOT_STICKY
        }
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (running) return
        val fd = Builder()
            .setSession("Unnal Mudiyum")
            .addAddress("10.111.0.1", 32)
            .addDnsServer(VPN_DNS)
            .addRoute(VPN_DNS, 32)
            .setBlocking(true)
            .establish() ?: return
        tun = fd
        running = true

        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        loop = Thread {
            val buf = ByteArray(32767)
            try {
                while (running) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (n == 0) continue
                    val pkt = buf.copyOf(n)
                    pool.execute { handle(pkt, output) }
                }
            } catch (_: Exception) {
                // The tunnel was closed.
            } finally {
                stopVpn()
            }
        }.also { it.start() }
    }

    @Synchronized
    private fun stopVpn() {
        running = false
        try {
            tun?.close()
        } catch (_: Exception) {
        }
        tun = null
        loop?.interrupt()
        loop = null
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        pool.shutdownNow()
        super.onDestroy()
    }

    // ---- Packet handling ----

    private fun handle(pkt: ByteArray, output: FileOutputStream) {
        try {
            if (pkt.size < 28) return
            if ((pkt[0].toInt() shr 4) != 4) return // IPv4 only
            val ihl = (pkt[0].toInt() and 0x0F) * 4
            if (pkt[9].toInt() != 17) return // UDP only
            if (pkt.size < ihl + 8 + 12) return
            val dstPort = ((pkt[ihl + 2].toInt() and 0xFF) shl 8) or (pkt[ihl + 3].toInt() and 0xFF)
            if (dstPort != 53) return
            val udpLen = ((pkt[ihl + 4].toInt() and 0xFF) shl 8) or (pkt[ihl + 5].toInt() and 0xFF)
            val end = minOf(pkt.size, ihl + udpLen)
            val dns = pkt.copyOfRange(ihl + 8, end)

            val name = parseQName(dns) ?: return
            val answer = if (Blocklist.isBlocked(name)) nxdomain(dns) else forward(dns)
            if (answer != null) {
                val reply = buildReply(pkt, ihl, answer)
                synchronized(output) { output.write(reply) }
            }
        } catch (_: Exception) {
            // Drop a bad packet. The app that asked will retry.
        }
    }

    private fun parseQName(dns: ByteArray): String? {
        var i = 12
        val sb = StringBuilder()
        while (i < dns.size) {
            val len = dns[i].toInt() and 0xFF
            if (len == 0) break
            if ((len and 0xC0) != 0) return null
            if (i + 1 + len > dns.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(dns, i + 1, len, Charsets.US_ASCII))
            i += len + 1
        }
        return if (sb.isEmpty()) null else sb.toString()
    }

    private fun questionEnd(dns: ByteArray): Int {
        var i = 12
        while (i < dns.size && dns[i].toInt() != 0) i += (dns[i].toInt() and 0xFF) + 1
        return minOf(dns.size, i + 1 + 4)
    }

    private fun nxdomain(dns: ByteArray): ByteArray {
        val r = dns.copyOf(questionEnd(dns))
        r[2] = (r[2].toInt() or 0x80).toByte() // response
        r[3] = 0x83.toByte() // recursion available, name does not exist
        for (k in 6..11) r[k] = 0 // no answer, authority or extra records
        return r
    }

    private fun forward(dns: ByteArray): ByteArray? = try {
        DatagramSocket().use { s ->
            protect(s) // keep this lookup outside our own tunnel
            s.soTimeout = 4000
            val addr = InetAddress.getByName(UPSTREAM)
            s.send(DatagramPacket(dns, dns.size, addr, 53))
            val rb = ByteArray(4096)
            val rp = DatagramPacket(rb, rb.size)
            s.receive(rp)
            rb.copyOf(rp.length)
        }
    } catch (_: Exception) {
        null
    }

    private fun buildReply(req: ByteArray, ihl: Int, dns: ByteArray): ByteArray {
        val udpLen = 8 + dns.size
        val total = ihl + udpLen
        val out = ByteArray(total)
        System.arraycopy(req, 0, out, 0, ihl)
        // Swap source and destination addresses.
        System.arraycopy(req, 16, out, 12, 4)
        System.arraycopy(req, 12, out, 16, 4)
        out[2] = (total shr 8).toByte()
        out[3] = total.toByte()
        out[6] = 0x40
        out[7] = 0
        out[8] = 64
        out[10] = 0
        out[11] = 0
        val sum = checksum(out, ihl)
        out[10] = (sum shr 8).toByte()
        out[11] = sum.toByte()
        // UDP header: swap ports, set length, checksum 0 (allowed for IPv4).
        out[ihl] = req[ihl + 2]
        out[ihl + 1] = req[ihl + 3]
        out[ihl + 2] = req[ihl]
        out[ihl + 3] = req[ihl + 1]
        out[ihl + 4] = (udpLen shr 8).toByte()
        out[ihl + 5] = udpLen.toByte()
        out[ihl + 6] = 0
        out[ihl + 7] = 0
        System.arraycopy(dns, 0, out, ihl + 8, dns.size)
        return out
    }

    private fun checksum(b: ByteArray, len: Int): Int {
        var sum = 0
        var i = 0
        while (i < len) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
        }
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }
}
