package com.unnalmudiyum.app.shield

/**
 * Local adult-site rules. This is the first layer. The VPN also forwards every
 * other lookup to Cloudflare's family DNS (1.1.1.3), which blocks adult sites
 * and malware, so this list only has to catch the obvious ones and keywords.
 */
object Blocklist {
    private val domains = setOf(
        "pornhub.com", "xvideos.com", "xnxx.com", "xhamster.com", "redtube.com",
        "youporn.com", "spankbang.com", "chaturbate.com", "stripchat.com",
        "eporner.com", "tube8.com", "brazzers.com", "porn.com", "beeg.com",
        "onlyfans.com", "motherless.com", "hentaihaven.xxx"
    )

    private val keywords = listOf(
        "porn", "xvideo", "xnxx", "xhamster", "hentai", "camgirl", "sexcam"
    )

    fun isBlocked(host: String): Boolean {
        val h = host.lowercase().trimEnd('.')
        if (domains.any { h == it || h.endsWith(".$it") }) return true
        return keywords.any { h.contains(it) }
    }
}
