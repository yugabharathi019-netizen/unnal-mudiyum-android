package com.unnalmudiyum.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unnalmudiyum.app.data.Prefs
import com.unnalmudiyum.app.shield.DnsBlockerVpnService
import com.unnalmudiyum.app.shield.ReelsGuardService
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun TodayScreen(state: AppState, go: (Int) -> Unit) {
    val ctx = LocalContext.current
    val foods = state.read { Prefs.foodsToday() }
    val kcal = foods.sumOf { it.kcal }
    val protein = foods.sumOf { it.protein }
    val tk = state.read { Prefs.targetKcal }
    val tp = state.read { Prefs.targetProtein }
    val workout = state.read { Prefs.workoutDone }
    val weights = state.read { Prefs.weights() }
    val goal = state.read { Prefs.goalKg }
    val height = state.read { Prefs.heightCm }
    val guardOn = state.read { ReelsGuardService.isEnabled(ctx) }
    val adultOn = state.read { Prefs.adultBlock && DnsBlockerVpnService.running }
    val blocked = state.read { Prefs.blockedToday() }
    val mode = state.read { Prefs.reelsMode }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM")),
                color = U.Muted, fontSize = 13.sp
            )
            Text("Vanakkam", color = U.Text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("உன்னால் முடியும்", color = U.Gold, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }

        // Shield status
        val shieldOn = guardOn || adultOn
        UCard(Modifier.clickable { go(1) }) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (shieldOn) U.Leaf else U.Muted)
                )
                Column(Modifier.weight(1f)) {
                    Text(
                        if (shieldOn) "Shield is on" else "Shield is off",
                        color = U.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        if (shieldOn) {
                            (if (adultOn) "Adult sites locked" else "Adult sites open") +
                                " · Reels: " + mode
                        } else "Tap to turn it on",
                        color = U.Muted, fontSize = 13.sp
                    )
                }
                Text("$blocked blocked", color = U.Gold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        // Rings
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            UCard(Modifier.weight(1f)) {
                SectionLabel("Protein")
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Ring(protein / tp.toFloat(), U.Gold, 112.dp, 10.dp) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$protein", color = U.Text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            Text("of $tp g", color = U.Muted, fontSize = 12.sp)
                        }
                    }
                }
                Text("${(tp - protein).coerceAtLeast(0)} g to go", color = U.Text, fontSize = 13.sp)
            }
            UCard(Modifier.weight(1f)) {
                SectionLabel("Calories")
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Ring(kcal / tk.toFloat(), U.Ivory, 112.dp, 10.dp) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("%,d".format(kcal), color = U.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Text("of %,d".format(tk), color = U.Muted, fontSize = 12.sp)
                        }
                    }
                }
                Text("%,d kcal to go".format((tk - kcal).coerceAtLeast(0)), color = U.Text, fontSize = 13.sp)
            }
        }

        // Workout
        UCard {
            SectionLabel("Today's workout")
            Text(
                if (workout) "Workout done" else "Not trained yet",
                color = if (workout) U.Leaf else U.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold
            )
            Text(
                "A full workout logger is coming next. For now, mark the day done. In Earn mode this opens your Reels time.",
                color = U.Muted, fontSize = 13.sp
            )
            if (workout) {
                GoldButton("Undo", { state.edit { Prefs.workoutDone = false } })
            } else {
                GoldButton("I trained today", { state.edit { Prefs.workoutDone = true } })
            }
        }

        // Weight
        UCard(Modifier.clickable { go(3) }) {
            SectionLabel("Body weight")
            if (weights.isEmpty()) {
                Text("No weight logged yet", color = U.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text("Tap to log your first weight.", color = U.Muted, fontSize = 13.sp)
            } else {
                val now = weights.last().kg
                val start = weights.first().kg
                val frac = if (goal > start) ((now - start) / (goal - start)).coerceIn(0f, 1f) else 0f
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("%.1f".format(now), color = U.Text, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text("kg", color = U.Muted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 6.dp))
                    Box(Modifier.weight(1f))
                    Text("Goal %.0f kg".format(goal), color = U.Muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(U.Track)
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(frac)
                            .height(8.dp)
                            .background(U.Gold)
                    )
                }
                val bmi = if (height > 0f) now / ((height / 100f) * (height / 100f)) else 0f
                Text(
                    "%.1f of %.1f kg gained".format(now - start, goal - start) +
                        (if (bmi > 0f) " · BMI %.1f".format(bmi) else ""),
                    color = U.Muted, fontSize = 12.sp
                )
            }
        }
    }
}
