package com.unnalmudiyum.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Unnal Mudiyum colors: warm charcoal with turmeric gold. */
object U {
    val Bg = Color(0xFF12100E)
    val Surface = Color(0xFF1B1713)
    val Raised = Color(0xFF241F19)
    val Line = Color(0xFF332B22)
    val Track = Color(0xFF2E261D)
    val Text = Color(0xFFF4ECDD)
    val Muted = Color(0xFFA89B87)
    val Gold = Color(0xFFE9AB3A)
    val OnGold = Color(0xFF1A1206)
    val Leaf = Color(0xFF7FBF7B)
    val Ivory = Color(0xFFD9CDB8)
}

@Composable
fun UnnalTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = U.Gold,
            onPrimary = U.OnGold,
            background = U.Bg,
            onBackground = U.Text,
            surface = U.Surface,
            onSurface = U.Text,
            surfaceVariant = U.Raised,
            onSurfaceVariant = U.Muted,
            outline = U.Line,
            secondary = U.Leaf
        ),
        content = content
    )
}

@Composable
fun UCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(U.Surface)
            .border(1.dp, U.Line, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text.uppercase(),
        color = U.Muted,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.9.sp
    )
}

@Composable
fun ScreenHeader(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = U.Text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = U.Muted, fontSize = 14.sp)
    }
}

@Composable
fun GoldButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = U.Gold,
            contentColor = U.OnGold,
            disabledContainerColor = U.Track,
            disabledContentColor = U.Muted
        )
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun Ring(
    progress: Float,
    color: Color,
    diameter: Dp,
    stroke: Dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val s = stroke.toPx()
            val arc = Size(this.size.width - s, this.size.height - s)
            val tl = Offset(s / 2, s / 2)
            drawArc(U.Track, 0f, 360f, false, topLeft = tl, size = arc, style = Stroke(s))
            drawArc(
                color, -90f, 360f * progress.coerceIn(0f, 1f), false,
                topLeft = tl, size = arc, style = Stroke(s, cap = StrokeCap.Round)
            )
        }
        content()
    }
}
